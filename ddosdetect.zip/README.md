# DDOS-Detection

Model: K-Nearest-Neighbours
The output is given in result.txt.


One can expect two kinds of results:
    
    -  Benign: benign
    -  DDOS: SRC: IP_SRC  DST: IP_DST 

##### NOTE: If any error occurs check if all the packages are installed
   
## Lib Used

- Scikit-Learn = 0.23.1
- Scapy
- Pandas
- Numpy
- Pickle
- OS
- tqdm
- argparse
